import React from 'react';
import { Link } from 'react-router-dom';
import '../form.scss'
export default function SignUp() {

    return (
        <div className="form-bg">
            <div className="container">
                <div className="login">
                    <h1>sign up</h1>
                    <form>
                        <div className="form-control">
                            <input type="text" required name="email" />
                            <label>Fullname</label>
                        </div>
                        <div className="form-control">
                            <input type="email" required name="email" />
                            <label>Email</label>
                        </div>
                        <div className="form-control">
                            <input type="password" required name="password" />
                            <label>Password</label>
                        </div>
                        <button type='submit' className="btn">Login</button>
                    </form>
                    <p className="text">
                        Already have an account? <Link to="/login">login</Link>
                    </p>
                </div>
            </div>
        </div>
    )
}
