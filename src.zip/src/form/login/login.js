import React from 'react'
import '../form.scss'
import { Link } from 'react-router-dom'
export default function Login() {
    return (
        <div>
            <div className="form-bg">
                <div className="container">
                    <div className="login">
                        <h1>Login</h1>
                        <form>
                            <div className="form-control">
                                <input type="email" required name="email" />
                                <label>Email</label>
                            </div>
                            <div className="form-control">
                                <input type="password" required name="password" />
                                <label>Password</label>
                            </div>
                            <button type='submit' className="btn">Login</button>
                        </form>
                        <p className="text">
                            Don't have an account? <Link to="/">Sign Up</Link>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    )
}
