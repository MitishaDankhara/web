import { createBrowserRouter } from "react-router-dom";
import SignUp from "../form/signup";
import Login from "../form/login/login";

const router = createBrowserRouter([
    {
        path: '/',
        element: <SignUp />
    },
    {
        path: '/login',
        element: <Login />
    }
])

export default router;